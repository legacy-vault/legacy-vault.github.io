// Legacy Vault.
// html_item_game.
// str.h.
// Last Edited on 2017-02-02.
// Version 1.4.

#ifndef STR_H
#define STR_H

char *createPath ( char *filePath, int size, char *a, char *b, char *fileName );
char *createPath2 ( char *filePath, int size, char *a, char *b, char *fileName, char *ext );

#endif
